// Google Analytics Event tracking codes - jQuery must be installed
// UNIVERSAL TRACKING CODE EXAMPLE: ga('send', 'event', 'category', 'action', 'opt_label', opt_value, {'nonInteraction': 1});
// The codes below are common examples and can be modified, combined or added to as needed

function addTracking(){ 
    $('a[href$="pdf"]').each(function() {
        $(this).attr('onclick', "ga('send', 'event', 'PDF', 'Clicked', jQuery(this).attr('href'), {'nonInteraction': 1});");
        $(this).attr('target', '_blank'); // OPTIONAL: ADD target blank
    });
    $('a[href$=".doc"], a[href$=".docx"], a[href$=".xls"], a[href$=".xlsx"], a[href$=".ppt"], a[href$=".pptx"]').each(function() {
    // ADD GA tracking code to links
    $(this).attr('onclick', "ga('send', 'event', 'Media', 'Clicked', jQuery(this).attr('href'), {'nonInteraction': 1});");
    }); 
    $('a[href^="http"],a[href^="//"]').each(function() {
    $(this).attr('onclick', "ga('send', 'event', 'Outbound', 'Clicked', jQuery(this).attr('href'), {'nonInteraction': 1});");
    $(this).attr('target', '_blank'); // OPTIONAL: ADD target blank
    });
    $(".pdfImage").each(function() {
        var currAction=$(this).attr('onclick');
        $(this).attr('onclick', currAction+";ga('send', 'event', 'Outbound', 'Clicked','PDFVIEW', {'nonInteraction': 1});");
    });
     $(".printImage").each(function() {
        var currAction=$(this).attr('onclick');
        $(this).attr('onclick', currAction+";ga('send', 'event', 'Outbound', 'Clicked','PRINTVIEW', {'nonInteraction': 1});");
    });
}


