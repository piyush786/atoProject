$(document).ready(function () {

    var videoId = getQuery("v"),
        videoOutput;

    function getQuery(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == variable) {
                return pair[1];
            }
        }
        return (false);
    }

    function sendToKaltura(destination, playerId) {
        videoOutput = '<img class="ratio" src="img/16x9.png" /><div id="kplayer" class="playerv3"></div><script type="text/javascript">try {var config = {"targetId": "kplayer", "playback": {"autoplay": true }, "provider": {"partnerId": "2426391", "uiConfId": "' + playerId + '", "env": {"serviceUrl": "https:\/\/www.kaltura.com\/api_v3", "cdnUrl": "https:\/\/cdnapisec.kaltura.com" } } }; var kalturaPlayer = PathKalturaPlayer.setup(config);kalturaPlayer.loadMedia({playlistId: "' + destination + '" });} catch (e) {console.error(e.message)}</script>';
    }
    function sendToGXBuilder(destination) {
        window.location.replace("https://dsi.alight.com/gxbuilder/preview/?v=" + destination);
    }

    //Mapping Rapt to Kaltura
    //Project Name                      Rapt ID     Kaltura ID  DynamoDB (GXBuilder) ID
    //---------------------------------------------------------------------------------  
    //AFA w/o Retirement                KHaVEDpi    1_z7mm7k61  1620025981434 (Now redirecting to https://dsi.alight.com/afa/no_retirement)
    //AFA w/Retirement                  2TYRG9A-    1_xctxyh0k  1621951689411 (Now redirecting to https://dsi.alight.com/afa/retirement)
    //Immersive Environment             akzrXv0z    1_v8d1y5ve  1614324792953
    //2018 Guided Experience Sales Demo aD_2jLwJ    1_2hsxpx3o
    //GX Demo Sample (B&W)              NoI1r4Zw    1_5v0ulzq0
    //2018 GX Demo (Full Version)       0Un0PCwN    1_u2q1i23g
    //2018 GX Non-Actor DD Demo         jfoPWm9I    1_vdvx7op8
    //Generic Animated GX               FUNyiWzG    1_ykfvjl35  1613557659334
    //Siemens New Hire GX               7bayXt3R    1_fehj5nuj
    //People Like Me                    OIwFQ-r5    1_aykjwikc  1613643967177
    //Animated GX Demo (V2)             egEiXsiJ    1_0jna3js2
    //Animated GX Demo (V1)             s_pmT1aF    1_mdquyt9q
    //Aon Financial Ed GX               QqhuVnNV    1_lv0wc6zy  1613988825955
    //Elective Choice                   LJEjWanJ    1_sqy0b7yj
    //Generic Personalization Demo      KAybjpXD    1_av5tyehi
    //FAQ/Lex Demo - Generic            1f-peAB1    1_e9yluq5b  1614159693112

    //financial-wellness-gx-ethan       B3YcwIFw    1_ebvd4b3i

    //financial-wellness-gx-group       2PfUNrQp    1_a73oaph9
    //financial-wellness-gx-amy         3YPM-DQL    1_rj74f1ne
    //honda                                         1_dkpy7nxk
    //test                                          1_vfabrjov
    var kalturaPlayerCode = 44375441;    //Corresponds to UA-6459246-150 (ah-prod.com)
    switch (videoId) {

        case 'B3YcwIFw': case '1_ebvd4b3i':
            sendToKaltura('1_ebvd4b3i', kalturaPlayerCode);
            break;
        case 'aCwqsC7k': case '1_80olhli1':
            sendToKaltura('1_80olhli1', kalturaPlayerCode);
            break;
        case '2PfUNrQp': case '1_a73oaph9':
            sendToKaltura('1_a73oaph9', kalturaPlayerCode);
            break;
        case '3YPM-DQL': case '1_rj74f1ne':
            sendToKaltura('1_rj74f1ne', kalturaPlayerCode);
            break;
        case 'KHaVEDpi': case '1_z7mm7k61':
            //sendToKaltura('1_z7mm7k61', kalturaPlayerCode);
            //sendToGXBuilder(1620025981434);
            window.location.replace("https://dsi.alight.com/afa/no_retirement");

            break;
        case '2TYRG9A-': case '1_xctxyh0k':
            //sendToKaltura('1_xctxyh0k', kalturaPlayerCode);
            //sendToGXBuilder(1621951689411);
            window.location.replace("https://dsi.alight.com/afa/retirement");

            break;
        case 'akzrXv0z': case '1_v8d1y5ve':
            //sendToKaltura('1_v8d1y5ve', kalturaPlayerCode);
            sendToGXBuilder(1614324792953);
            break;
        case 'aD_2jLwJ': case '1_2hsxpx3o':
            sendToKaltura('1_2hsxpx3o', kalturaPlayerCode);
            break;
        case 'NoI1r4Zw': case '1_5v0ulzq0':
            sendToKaltura('1_5v0ulzq0', kalturaPlayerCode);
            break;
        case '0Un0PCwN': case '1_u2q1i23g':
            sendToKaltura('1_u2q1i23g', kalturaPlayerCode);
            break;
        case 'jfoPWm9I': case '1_vdvx7op8':
            sendToKaltura('1_vdvx7op8', kalturaPlayerCode);
            break;
        case 'FUNyiWzG': case '1_ykfvjl35':
            //sendToKaltura('1_ykfvjl35', kalturaPlayerCode);
            sendToGXBuilder(1613557659334);
            break;
        case '7bayXt3R': case '1_fehj5nuj':
            sendToKaltura('1_fehj5nuj', kalturaPlayerCode);
            break;
        case 'OIwFQ-r5': case '1_aykjwikc':
            //sendToKaltura('1_aykjwikc', kalturaPlayerCode);
            sendToGXBuilder(1613643967177);
            break;
        case 's_pmT1aF': case '1_mdquyt9q':
            sendToKaltura('1_mdquyt9q', kalturaPlayerCode);
            break;
        case 'egEiXsiJ': case '1_0jna3js2':
            sendToKaltura('1_0jna3js2', kalturaPlayerCode);
            break;
        case 'QqhuVnNV': case '1_lv0wc6zy':
            //sendToKaltura('1_lv0wc6zy', kalturaPlayerCode);
            sendToGXBuilder(1613988825955);
            break;
        case 'LJEjWanJ': case '1_sqy0b7yj':
            sendToKaltura('1_sqy0b7yj', kalturaPlayerCode);
            break;
        case 'KAybjpXD': case '1_av5tyehi':
            sendToKaltura('1_av5tyehi', kalturaPlayerCode);
            break;
        case '1f-peAB1': case '1_e9yluq5b':
            //sendToKaltura('1_e9yluq5b', kalturaPlayerCode);
            sendToGXBuilder(1614159693112);
            break;
        case '1_dkpy7nxk':
            sendToKaltura('1_dkpy7nxk', kalturaPlayerCode);
            break;
        case '1_vfabrjov':
            sendToKaltura('1_vfabrjov', kalturaPlayerCode);
            break;
        default:
            //Set videoOutput to the legacy Rapt player if no ID is found in the mapping
            videoOutput = '<img class="ratio" src="img/16x9.png"/>\n<iframe src="//cdn1.raptmedia.com/projects/' + videoId + '/embed?autoplay=true&controls=overlay" width=720 height=405 scrolling=no frameborder=0 marginheight=0 marginwidth=0 webkitallowfullscreen=true mozallowfullscreen=true allowfullscreen=true><p style="text-align:center">Iframes are required to view this content.</p></iframe>';
    }

    if (videoId !== false) {
        $('.video').show();
        $('.outer-container').html(videoOutput).show();
    } else {
        $('#error').show();
    }

});