$(function() {
  var getQueryString = function(key) {
    var href = window.location.href;
    var reg = new RegExp( '[?&]' + key + '=([^&#]*)', 'i' );
    var tempString = reg.exec(href);
    return tempString ? tempString[1].replace(/%20/gi,'').toUpperCase() : null;
  };

  var brightcoveId = getQueryString('v');
  videojs.getPlayer("myPlaylistID").ready(function() {
  	var myPlaylist = this;
    myPlaylist.catalog.getPlaylist(brightcoveId, function(error, playlist) {
      myPlaylist.catalog.load(playlist);
      var name = myPlaylist.mediainfo.name;
      $("title").html("Playlist");
      myPlaylist.play();
    });
  });

});