var myPlayer;
var getQueryString = function (key) {
    var reg = new RegExp('[?&]' + key + '=([^&#]*)', 'i');
    var tempString = reg.exec(window.location.href);
    return tempString ? tempString[1].replace(/%20/gi, '').toUpperCase() : null;
};

var brightcoveId = getQueryString('v');

if (!brightcoveId) {
    $('#preload').hide();
    $('#error').show();
}

videojs.getPlayer('myPlayerID').ready(function () {
    myPlayer = this;
    $(".vjs-loading-spinner .vjs-control-text")
        .text("Video Player is loaded.");
    var videoWidth;
    var videoHeight;
    myPlayer.catalog.getVideo(brightcoveId, function (error, video) {
        if (!error) {
            myPlayer.catalog.load(video);
            var name = myPlayer.mediainfo.name;
            $("title, h1").html(name);
            $("#video, .containing-block").fadeIn(400);
            for (i = 0; i < video.sources.length; i++) {
                videoWidth = video.sources[i].width;
                videoHeight = video.sources[i].height;
                if (videoWidth && videoHeight) {
                    break;
                }
            }
            var paddingTop = (videoHeight / videoWidth) * 100 > 56.25 ? 75 : 56.25;
            $('#player .outer-container').css('padding-top', paddingTop + '%');
            myPlayer.play();

            loadTR_AD();

        } else {
            console.log(error);
            window.location = 'playlist.html?v=' + brightcoveId;
        }
    });
});

function loadTR_AD(){
    if (myPlayer.mediainfo.customFields['ad_video_version_id']) {
        $(".adStatement").show();
        $(".adLink").attr("href", "./player.html?v=" + myPlayer.mediainfo.customFields['ad_video_version_id']);
    } else {
        $(".adStatement").hide();
    }

    if (myPlayer.mediainfo.transcripts != undefined && myPlayer.mediainfo.transcripts[1]) {
        $(".trStatement").show();

        var link = document.getElementById('trLink');

        link.onclick = function (event) {
            event.preventDefault();
            const element = document.getElementsByClassName('transcriptWindow')[0];
            const isHidden = window.getComputedStyle(element).display === 'none';
            if (isHidden) {
                element.style.display = 'block';
            } else {
                element.style.display = 'none';
            }
        };

        fetch(myPlayer.mediainfo.transcripts[1].src)
            .then(response => response.text())
            .then(data => {
                console.log(data);
                $(".transcriptContent").html("<strong>Transcript:</strong> " + data);
            })
            .catch(error => {
                $(".transcriptContent").html(error);
            });

    } else {
        $(".trStatement").hide();
    }

}