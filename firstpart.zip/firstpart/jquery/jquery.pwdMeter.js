/**
@name jQuery pwdMeter 1.0.1
@author Shouvik Chatterjee (mailme@shouvik.net)
@date 31 Oct 2010
@modify 31 Dec 2010
@license Free for personal and commercial use as long as the author's name retains
@modified by John Brady 13 September 2011 to support a confirm password box + removed the random/generate functionality
*/
(function (jQuery) {

    jQuery.fn.pwdMeter = function (options) {


        options = jQuery.extend({

            minLength: 6,
            displayGeneratePassword: false,
            generatePassText: 'Password Generator',
            generatePassClass: 'GeneratePasswordLink',
            randomPassLength: 13,
            passwordBox: this

        }, options);


        return this.each(function (index) {

            jQuery(this).keyup(function () {
                evaluateMeter();
            });


            function evaluateMeter() {

                var passwordStrength = 0;
                var password = jQuery(options.passwordBox).val();

                // if ((password.length > 0) && (password.length <= 6)) passwordStrength = 1;

                if (password.length >= options.minLength) passwordStrength++;

                if ((password.match(/[a-z]/)) && (password.match(/[A-Z]/))) passwordStrength++;

                if (password.match(/\d+/)) passwordStrength++;

                if (password.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/)) passwordStrength++;

                if (password.length > 12) passwordStrength++;

                var selector = '#pwdMeter';
                if (options.confirm) {
                    selector = '#pwdMeterConfirm';
                }

                jQuery(selector).removeClass();
                jQuery(selector).addClass('Password-Meter-neutral');

                switch (passwordStrength) {
                    case 1:
                        jQuery(selector).addClass('Password-Meter-veryWeak');
                        jQuery(selector).html('<span class="Password-Meter-text">' + locale.veryWeek + '</span>');
                        break;
                    case 2:
                        jQuery(selector).addClass('Password-Meter-weak');
                        jQuery(selector).html('<span class="Password-Meter-text">' + locale.weak + '</span>');
                        break;
                    case 3:
                        jQuery(selector).addClass('Password-Meter-medium');
                        jQuery(selector).html('<span class="Password-Meter-text">' + locale.medium + '</span>');
                        break;
                    case 4:
                        jQuery(selector).addClass('Password-Meter-strong');
                        jQuery(selector).addClass('strong');
                        jQuery(selector).html('<span class="Password-Meter-text">' + locale.strong + '</span>');
                        break;
                    case 5:
                        jQuery(selector).addClass('Password-Meter-veryStrong');
                        jQuery(selector).addClass('strong');
                        jQuery(selector).html('<span class="Password-Meter-text">' + locale.veryStrong + '</span>');
                        break;
                    default:
                        jQuery(selector).addClass('Password-Meter-neutral');
                }

            }


        });

    }

})(jQuery)
