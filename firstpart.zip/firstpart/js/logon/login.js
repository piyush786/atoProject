var RSA_E;
var RSA_M;

var pwRegex;
var locale = {
    veryWeek: 'Very Weak',
    weak: 'Weak',
    medium: 'Medium Strength',
    strong: 'Strong',
    veryStrong: 'Very Strong',
    SecurityQuestionSave: 'Your new password has been saved successfully. Please wait while you are being redirected to Your Total Rewards Page.'
};

var message = {
    maxInvalPassAtmpt: 'You have entered your password incorrectly too many times, you will be redirected to verify your account with an Authentication Code and create a new password.',
    requiredField: '*Required Field',
    noMatch: 'New password and confirmed passwords do not match.',
    systemError: 'An error occurred !',
    ContactAlert: 'Your account is locked. Contact Human Resources to have your account reset. You will need your Personnel Number.',
    passwordRequirements: 'Your password must be between 8 - 12 characters and contain at least one upper case letter, one lower case letter, one number, and one special character.',
};

var sessionKey = {
    UserName: "UserName",
    Token: "Token",
    SSOData: "SSOData",
    RefreshToken: "RefreshToken"
}

var environmentString = location.hostname;
var webApiRootUrl, environment;

if (environmentString.indexOf("qa") >= 0) {
    /*webApiRootUrl = "https://cawiqapp0030.hewitt.com:8088/ato/api/Login";  */
    webApiRootUrl = "https://ceservice.qa.alight.com/ato/api/Login";
    environment = 'qa';
} else if (environmentString.indexOf("qc") >= 0) {
    webApiRootUrl = "https://ceservice.qc.alight.com/ato/api/Login";
    environment = 'qc';
} else if (environmentString.indexOf("127.0.0.1") >= 0) {
    webApiRootUrl = "http://localhost:57858/api/Login";
    environment = 'rs';
} else if (environmentString.indexOf("localhost") >= 0) {
    webApiRootUrl = "http://localhost:57858/api/Login";
    environment = 'localhost';
} else if (environmentString.indexOf("svnclientprd.hewitt.com") >= 0) {
    webApiRootUrl = "https://ceservice.qa.alight.com/ato/api/Login";
    environment = 'localhost';
}
else {
    webApiRootUrl = "https://ceservice.alight.com/ato/api/Login";
    environment = 'production';
}

console.log(environment, webApiRootUrl);


function GetLoginFlags() {
    var encryptedUsername = sessionStorage.getItem(sessionKey.UserName);
    var loginFlags = null;
    if (encryptedUsername != null) {
        jQuery.ajax({
            type: "POST",
            url: webApiRootUrl + "/GetLoginFlags",
            data: JSON.stringify(encryptedUsername),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            cache: false,
            async: false,
            success: function (result) {
                console.log(result);
                if (result != null) {
                    loginFlags = result;
                }
            },
            error: function (error) {
                console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
            }
        })
    }
    return loginFlags;
}

function GetRSAKeyData() {
    jQuery.ajax({
        type: "GET",
        url: webApiRootUrl + "/GetRSAKeyData",
        data: {},
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        cache: false,
        async: true,
        success: function (result) {
            console.log(result);
            if (result != null) {
                RSA_E = result["rsA_E"];
                RSA_M = result["rsA_M"];
                console.log(RSA_E, RSA_M);
            }
        },
        error: function (error) {
            console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
        }
    })
}


function EncrypteData(data) {
    setMaxDigits(131);
    var key = new RSAKeyPair(RSA_E, "", RSA_M);
    console.log("key", key);
    var encryedData = encryptedString(key, base64encode(strUnicode2Ansi(data)));
    return encryedData;
}

function SendUsername() {
    if (FormValidation()) {
        var username = $("#UserName").val();
        var encryptedUsername = EncrypteData(username);

        jQuery.ajax({
            type: "POST",
            url: webApiRootUrl + "/ValidateUsername",
            data: JSON.stringify(encryptedUsername),
            headers: {
                'X-Host-Name': window.location.hostname
            },
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            cache: false,
            async: true,
            success: function (result) {
                console.log(result, result.status, result.errorMsg, result.isFirstTimeUser);
                if (result.status == true) {
                    $("#UserName").attr("aria-invalid", "false");
                    sessionStorage.setItem(sessionKey.UserName, encryptedUsername);
                    if (result.isFirstTimeUser == true) {
                        location.href = "enter-code.html";
                    }
                    else {
                        location.href = "enter-password.html";
                    }
                }
                else {
                    if (result.errorMsg != '') {
                        $("#errormessage").text("");
                        setTimeout(function () {
                            $("#errormessage").text(result.errorMsg);
                        }, 100);
                        $("#UserName").attr("aria-invalid", "true");
                    }
                }
            },

            error: function (error) {
                console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
            }
        })

    }
}

function ResendOTP() {
    var encryptedUsername = sessionStorage.getItem(sessionKey.UserName);
    console.log("Encrypted Username:", encryptedUsername);

    if (!encryptedUsername) {
        $("#errormessage").text("Username not found in session.");
        return;
    }

    var apiUrl = webApiRootUrl + "/ResendCode";
    console.log("Calling API:", apiUrl);

    jQuery.ajax({
        type: "POST",
        url: apiUrl,
        data: JSON.stringify(encryptedUsername),
        headers: {
            'X-Host-Name': window.location.hostname
        },
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        cache: false,
        async: true,
        success: function (result) {
            console.log(result, result.status, result.errorMsg);
            console.log("API Response:", result);
            if (result.status == true) {
                location.href = "enter-code.html";
            } else {
                $("#errormessage").text(result.errorMsg);
            }
        },
        error: function (error) {
            console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
        }
    });
}


function ValidateOTP() {
    if (($('#txtPasscode').length > 0)) {
        let txtPasscode = $("#txtPasscode").val();
        if (txtPasscode == "") {
            $("#txtPasscode").css("border", "1px solid #AC0808");
            $("#txtPasscode").attr("aria-invalid", "true");
            alert("Please enter a 6-digit authentication code.");
        }
        else {
            $("#txtPasscode").css("border", "1px solid #dee2e6");
            $("#txtPasscode").attr("aria-invalid", "false");
            var encryptedUsername = sessionStorage.getItem(sessionKey.UserName);
            jQuery.ajax({
                type: "POST",
                url: webApiRootUrl + "/ValidateAuthCode",
                data: JSON.stringify(
                    {
                        "Username": encryptedUsername,
                        "Code": txtPasscode
                    }
                ),
                headers: {
                    'X-Host-Name': window.location.hostname
                },
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                cache: false,
                async: true,
                success: function (result) {
                    console.log(result, result.status, result.token, result.errorMsg);
                    if (result.status == true) {
                        $("#txtPasscode").attr("aria-invalid", "false");
                        if (loginFlags.isResetPassword == true || loginFlags.isProfileComplete == false) {
                            location.href = "set-password.html";
                        } else {
                            sessionStorage.setItem(sessionKey.Token, result.token);
                            sessionStorage.setItem(sessionKey.RefreshToken, result.refreshToken);
                            location.href = "welcome.html";
                        }
                    } else {
                        if (result.errorMsg != '') {
                            $("#errormessage").text("");
                            setTimeout(function () {
                                $("#errormessage").text(result.errorMsg);
                            }, 100);
                            $("#UserName").attr("aria-invalid", "true");
                        } else {
                            location.href = "logon.html";
                        }
                    }
                },
                error: function (error) {
                    console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
                }
            })
        }
    }
}

function ForgetPassword() {
    var encryptedUsername = sessionStorage.getItem(sessionKey.UserName);

    jQuery.ajax({
        type: "POST",
        url: webApiRootUrl + "/ForgotPassword",
        data: JSON.stringify(encryptedUsername),
        headers: {
            "X-Host-Name": window.location.hostname,
        },
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        cache: false,
        async: true,
        success: function (result) {
            console.log(result, result.status, result.errorMsg);
            if (result.status == true) {
                sessionStorage.setItem(sessionKey.UserName, encryptedUsername);
                location.href = "enter-code.html";
            } else {
                if (result.errorMsg != "") {
                    $("#errormessage").text(result.errorMsg);
                }
            }
        },

        error: function (error) {
            console.log(
                "state: " + error.state,
                "; Status:" + error.status,
                "; Response Text: " + error.responseText
            );
        },
    });
}

function SendPassword() {
    let password = $("#Password").val();
    if (password == "") {
        $("#Password").css("border", "1px solid #AC0808");
        $("#Password").attr("aria-invalid", "true");
        alert("Please enter a password.");
    }
    else {
        $("#Password").css("border", "1px solid #dee2e6");
        $("#Password").attr("aria-invalid", "false");
        var encryptedUsername = sessionStorage.getItem(sessionKey.UserName);
        var encrpyedPass = EncrypteData(password);
        jQuery.ajax({
            type: "POST",
            url: webApiRootUrl + "/ValidatePassword",
            data: JSON.stringify(
                {
                    Username: encryptedUsername,
                    Password: encrpyedPass
                }),
            headers: {
                'X-Host-Name': window.location.hostname
            },
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            cache: false,
            async: true,
            success: function (result) {
                console.log(result, result.status, result.errorMsg, result.isUserLocked);
                if (result.status == true) {
                    $("#Password").attr("aria-invalid", "false");
                    location.href = "enter-code.html";
                } else {
                    if (result.errorMsg != "") {
                        $("#Password").attr("aria-invalid", "true");
                        if (result.isUserLocked == true) {
                            alert(result.errorMsg);
                            ResendOTP();
                            location.href = "enter-code.html";
                        } else {
                            $("#errormessage").text(result.errorMsg);
                            $("#Password").attr("aria-invalid", "true");
                        }
                    }
                }
            },
            error: function (error) {
                console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
            }
        })
    }
}

function handle(e) {
    if (e.keyCode === 13) {
        event.preventDefault();
        var button = document.getElementById("LoginButton");
        button.click();
    }
}

function FormValidation() {
    if (($('#UserName').length > 0)) {
        var flag = true;
        let txtUser = $("#UserName").val();

        if (txtUser == "") {
            $("#UserName").css("border", "1px solid #AC0808");
            $("#errormessage").text("");
            setTimeout(function () {
                $("#errormessage").text("Email Address is required.");
            }, 100);
            $("#UserName").attr("aria-invalid", "true");
            flag = false;
        }
        else if (!EmailCheck()) {
            $("#UserName").attr("aria-invalid", "true");
            flag = false;
        }
        else {
            $("#UserName").css("border", "1px solid #dee2e6");
        }

        return flag;
    }
};

function Validate() {
    let txtUser = $("#UserName").val();
    if (txtUser == "") {
        $("#UserName").css("border", "1px solid #AC0808");
        return false;
    }
    else {
        $("#UserName").css("border", "1px solid #dee2e6");
        return true;
    }
};

function EmailCheck() {
    for (var k = 0; k <= 1; k++) {
        var emailStr = "";
        if (k == 0) {
            emailStr = $("#UserName").val();
        }

        if (emailStr != "") {
            /* The following variable tells the rest of the function whether or not
            to verify that the address ends in a two-letter country or well-known
            TLD.  1 means check it, 0 means don't. */

            var checkTLD = 1;

            /* The following is the list of known TLDs that an e-mail address must end with. */

            var knownDomsPat = /^(com|COM|net|NET|org|ORG|edu|EDU|int|INT|mil|MIL|gov|GOV|arpa|ARPA|biz|BIZ|aero|AERO|name|NAME|coop|COOP|info|INFO|pro|PRO|museum|MUSEUM)$/;

            /* The following pattern is used to check if the entered e-mail address
            fits the user@domain format.  It also is used to separate the username
            from the domain. */

            var emailPat = /^(.+)@(.+)$/;

            /* The following string represents the pattern for matching all special
            characters.  We don't want to allow special characters in the address. 
            These characters include ( ) < > @ , ; : \ " . [ ] */

            var specialChars = "\\(\\)><@,;:\\\\\\\"\\.\\[\\]";

            /* The following string represents the range of characters allowed in a 
            username or domainname.  It really states which chars aren't allowed.*/

            var validChars = "\[^\\s" + specialChars + "\]";

            /* The following pattern applies if the "user" is a quoted string (in
            which case, there are no rules about which characters are allowed
            and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
            is a legal e-mail address. */

            var quotedUser = "(\"[^\"]*\")";

            /* The following pattern applies for domains that are IP addresses,
            rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
            e-mail address. NOTE: The square brackets are required. */

            var ipDomainPat = /^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;

            /* The following string represents an atom (basically a series of non-special characters.) */

            var atom = validChars + '+';

            /* The following string represents one word in the typical username.
            For example, in john.doe@somewhere.com, john and doe are words.
            Basically, a word is either an atom or quoted string. */

            var word = "(" + atom + "|" + quotedUser + ")";

            // The following pattern describes the structure of the user

            var userPat = new RegExp("^" + word + "(\\." + word + ")*$");

            /* The following pattern describes the structure of a normal symbolic
            domain, as opposed to ipDomainPat, shown above. */

            var domainPat = new RegExp("^" + atom + "(\\." + atom + ")*$");

            /* Finally, let's start trying to figure out if the supplied address is valid. */

            /* Begin with the coarse pattern to simply break up user@domain into
            different pieces that are easy to analyze. */

            var matchArray = emailStr.match(emailPat);

            if (matchArray == null) {

                /* Too many/few @'s or something; basically, this address doesn't
                even fit the general mould of a valid e-mail address. */

                /*alert("Email Address Incorrect");*/
                alert("Your email address is not valid, please verify the email address entered. If the email address entered is correct, please contact your Premier Company recruiter to have it updated.");
                if (k == 0) {
                    $("#UserName").css("border", "1px solid #AC0808");
                }
                return false;
            }
            var user = matchArray[1];
            var domain = matchArray[2];

            // Start by checking that only basic ASCII characters are in the strings (0-127).

            for (i = 0; i < user.length; i++) {
                if (user.charCodeAt(i) > 127) {
                    alert("Username Invalid");
                    if (k == 0) {
                        $("#UserName").css("border", "1px solid #AC0808");
                    }
                    return false;
                }
            }
            for (i = 0; i < domain.length; i++) {
                if (domain.charCodeAt(i) > 127) {
                    alert("Email Domain is Invalid");
                    if (k == 0) {
                        $("#UserName").css("border", "1px solid #AC0808");
                    }
                    return false;
                }
            }

            // See if "user" is valid 

            if (user.match(userPat) == null) {

                // user is not valid

                alert("Invalid Email Username");
                if (k == 0) {
                    $("#UserName").css("border", "1px solid #AC0808");
                }

                return false;
            }

            /* if the e-mail address is at an IP address (as opposed to a symbolic
            host name) make sure the IP address is valid. */

            var IPArray = domain.match(ipDomainPat);
            if (IPArray != null) {

                // this is an IP address

                for (var i = 1; i <= 4; i++) {
                    if (IPArray[i] > 255) {
                        alert("Invalid Email Address");
                        if (k == 0) {
                            $("#UserName").css("border", "1px solid #AC0808");
                        }
                        return false;
                    }
                }
                return true;
            }

            // Domain is symbolic name.  Check if it's valid.

            var atomPat = new RegExp("^" + atom + "$");
            var domArr = domain.split(".");
            var len = domArr.length;
            for (i = 0; i < len; i++) {
                if (domArr[i].search(atomPat) == -1) {
                    alert("The domain name does not seem to be valid.");
                    if (k == 0) {
                        $("#UserName").css("border", "1px solid #AC0808");
                    }
                    return false;
                }
            }

            /* domain name seems valid, but now make sure that it ends in a
            known top-level domain (like com, edu, gov) or a two-letter word,
            representing country (uk, nl), and that there's a hostname preceding 
            the domain or country. */

            if (checkTLD && domArr[domArr.length - 1].length != 2 &&
                domArr[domArr.length - 1].search(knownDomsPat) == -1) {
                alert("Invalid Email Address");
                if (k == 0) {
                    $("#UserName").css("border", "1px solid #AC0808");
                }
                return false;
            }

            // Make sure there's a host name preceding the domain.

            if (len < 2) {
                alert("Invalid Email Address");
                if (k == 0) {
                    $("#UserName").css("border", "1px solid #AC0808");
                }
                return false;
            }
        }//End of IF emailStr != ""
    }//End of FOR Loop
    return true;
}

function GetServiceData() {
    sessionStorage.removeItem(sessionKey.SSOData);
    var token = sessionStorage.getItem(sessionKey.Token);
    var refreshToken = sessionStorage.getItem(sessionKey.RefreshToken);
    var isTokenActive = true;
    console.log(token);
    if (token != null) {
        var isTokenExpired = IsTokenExpired(token);
        if (isTokenExpired) {
            console.log("Token is Expired");
            isTokenActive = RefreshToken(token, refreshToken);
        }
        console.log("isTokenActive" + isTokenActive);
        if (isTokenActive) {
            token = sessionStorage.getItem(sessionKey.Token);

            jQuery.ajax({
                type: "GET",
                url: webApiRootUrl + "/GetRewardsData",
                headers: {
                    'X-Host-Name': window.location.hostname,
                    Authorization: 'Bearer ' + token
                },
                data: {},
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                cache: false,
                async: false,
                success: function (result) {
                    console.log(result, result.ssoData);
                    if (result.ssoData != null) {
                        sessionStorage.setItem(sessionKey.SSOData, result.ssoData);
                    }
                },
                error: function (error) {
                    console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
                }
            })
        }

    }

}

function IsTokenExpired(token) {
    const tokenPart = token.split('.');
    const payload = JSON.parse(atob(tokenPart[1]));
    const exp = new Date(payload.exp * 1000);
    const currentTime = Math.floor(Date.now() / 1000);
    console.log(payload.exp, "-", exp, "-", Date.now(), "-", currentTime);
    return payload.exp < currentTime;
}

function RefreshToken(accessToken, refreshToken) {
    var IsTokenRefreshed = false;
    jQuery.ajax({
        type: "POST",
        url: webApiRootUrl + "/RefreshToken",
        data: JSON.stringify(
            {
                accessToken: accessToken,
                refreshToken: refreshToken
            }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        cache: false,
        async: false,
        success: function (result) {
            console.log(result);
            if (result.accessToken != "" && result.refreshToken != "") {
                sessionStorage.setItem(sessionKey.Token, result.accessToken);
                sessionStorage.setItem(sessionKey.RefreshToken, result.refreshToken);
                IsTokenRefreshed = true;
            }
        },
        error: function (error) {
            console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
        }
    })
    return IsTokenRefreshed;
}

function LogoutEmployee() {
    var logoutStatus = false;

    var encryptedUsername = sessionStorage.getItem(sessionKey.UserName);
    console.log("Encrypted Username:", encryptedUsername);

    var token = sessionStorage.getItem(sessionKey.Token);

    if (token) {
        // Token exists, call LogoutEmployee API
        jQuery.ajax({
            type: "POST",
            url: webApiRootUrl + "/LogoutEmployee",
            data: {},
            headers: {
                'X-Host-Name': window.location.hostname,
                Authorization: 'Bearer ' + token
            },
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            cache: false,
            async: false,
            success: function (result) {
                logoutStatus = result;
            },
            error: function (error) {
                console.error("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
            }
        });
    } else {
        // Token is null, call Exit API
        jQuery.ajax({
            type: "POST",
            url: webApiRootUrl + "/Exit",
            data: JSON.stringify(encryptedUsername),
            headers: {
                'X-Host-Name': window.location.hostname
            },
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            cache: false,
            async: false,
            success: function (result) {
                logoutStatus = result;
            },
            error: function (error) {
                console.error("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
            }
        });
    }

    return logoutStatus;
}

function Logoff() {
    LogoutEmployee();
    sessionStorage.clear();
    location.reload();
}


function ValidateRequest() {
    const queryString = window.location.search;
    console.log(queryString);
    const urlParams = new URLSearchParams(queryString);
    var requestToken = urlParams.get('request');
    jQuery.ajax({
        type: "POST",
        url: webApiRootUrl + "/LoginAsEmployee?requestToken=" + encodeURIComponent(requestToken),
        data: {},
        headers: {
            'X-Host-Name': window.location.hostname
        },
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        cache: false,
        async: true,
        success: function (result) {
            console.log(result);
            if (result.token != "" && result.refreshToken != "") {
                sessionStorage.setItem(sessionKey.Token, result.token);
                sessionStorage.setItem(sessionKey.RefreshToken, result.refreshToken);

            }
            location.href = "welcome.html";
        },

        error: function (error) {
            console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
        }
    })

}

/*************************** Reset Password JS Method ******************************/

function SetPassword() {
    if (CheckRequiredField(jQuery('#txtPassword')) & CheckRequiredField(jQuery('#txtPasswordConfirm'))) {
        ClearError();
        ShowSpinButton();
        var newPassword = $('#txtPassword').val();
        if (newPassword != $('#txtPasswordConfirm').val())
            ShowError(message.noMatch);
        else if (newPassword.match(pwRegex) == null)
            ShowError(message.passwordRequirements);
        else {
            var username = sessionStorage.getItem(sessionKey.UserName);
            var encryedPass = EncrypteData(newPassword);
            jQuery.ajax({
                cache: false,
                async: true,
                type: "POST",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(
                    {
                        Username: username,
                        Password: encryedPass
                    }),
                headers: {
                    'X-Host-Name': window.location.hostname
                },
                url: webApiRootUrl + "/ResetPassword",

                success: function (result) {
                    if (result.status == true && result.token != "" && result.refreshToken != "") {
                        sessionStorage.setItem(sessionKey.Token, result.token);
                        sessionStorage.setItem(sessionKey.RefreshToken, result.refreshToken);
                        alert(locale.SecurityQuestionSave);
                        location.href = "welcome.html";
                    }
                    else {
                        ClearSpinButton();
                        if (result.error != "") {
                            ShowError(result.error)
                        }
                        else {
                            location.href = "logon.html";
                        }
                    }
                },
                error: function (error) {
                    ClearSpinButton();
                    console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
                }
            });
        }
    }
}


function Logon() {
    const userConfirmed = confirm("Do you want to exit from site?");
    if (userConfirmed) {
        location.href = "logon.html";
    }
}


function CheckRequiredField(f, type) {
    if (f.val().length < 1) {
        ShowValidator(f, type);
        return false;
    }
    else
        HideValidator(f, type);
    return true;
}


function ShowValidator(f, type) {
    var requiredIndicator = f.attr('requiredvalidatormsg');
    var meter = f.attr('meter');

    jQuery('#' + requiredIndicator).show();
    if (meter)
        jQuery('#' + meter).hide();

    if (type == 1) {
        if (f.val().length < 1) {
            jQuery('#pwdMeter').hide();
            jQuery('.Password-Meter-text').hide();
        }
    }
    return false;
}


function HideValidator(f, type) {
    var requiredIndicator = f.attr('requiredvalidatormsg');
    var meter = f.attr('meter');

    jQuery('#' + requiredIndicator).hide();
    if (meter)
        jQuery('#' + meter).show();
    if (type == 1) {
        if (f.val().length < 1) {
            jQuery('.Password-Meter-text').hide();
        }
    }
}

function togglePswd(id, btn) {
    var x = document.getElementById(id);

    if (x.type === "password") {

        $(btn).html("<i class='fa fa-eye-slash'></i>");
        x.type = "text";

        btn.setAttribute("aria-pressed", "true");
        btn.setAttribute("aria-label", "Hide password");

    } else {

        $(btn).html("<i class='fa fa-eye'></i>");
        x.type = "password";

        btn.setAttribute("aria-pressed", "false");
        btn.setAttribute("aria-label", "Show password");
    }
}


function ShowSpinButton() {
    jQuery('#btnSetPassword').unbind();
}

function ClearSpinButton() {
    jQuery('#btnSetPassword').unbind();
    jQuery('#btnSetPassword').bind('click', SetPassword);
}

function ShowError(msg) {
    ClearSpinButton();
    jQuery('#lblError').text(''); // Clear existing error first
    setTimeout(function () {
        jQuery('#lblError').text(msg); // Add the error again so screen reader announces it
    }, 100);
    jQuery('#lblError').show();
    jQuery('#divfailureTxt').show();
}

function ClearError() {
    jQuery('#lblError').hide();
    jQuery('#lblError').html('');
    jQuery('#divfailureTxt').hide();
}

/************************************ Download PDF********************************************** */
function DownloadFile() {
    jQuery.ajax({
        type: "POST",
        url: webApiRootUrl + "/DownloadPDF",
        data: {},
        headers: {
            'X-Host-Name': window.location.hostname
        },
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        cache: false,
        async: true,
        success: function (result) {
            var fileName = '0545746.pdf'
            var bytes = Base64ToBytes(result.file);
            var blob = new Blob([bytes], { type: "application/octetstream" });
            var isIE = false || !!document.documentMode;
            if (isIE) {
                window.navigator.msSaveBlob(blob, fileName);
            } else {
                var url = window.URL || window.webkitURL;
                link = url.createObjectURL(blob);
                var a = $("<a />");
                a.attr("download", fileName);
                a.attr("href", link);
                $("body").append(a);
                a[0].click();
                $("body").remove(a);
            }
        },

        error: function (error) {
            console.log("state: " + error.state, "; Status:" + error.status, "; Response Text: " + error.responseText);
        }
    })

}
function Base64ToBytes(base64) {
    var s = window.atob(base64);
    var bytes = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) {
        bytes[i] = s.charCodeAt(i);
    }
    return bytes;
};

function UrlRouting() {
    var currentUrl = window.location.href;
    if (currentUrl.endsWith('.html')) {
        var newUrl = currentUrl.replace(/\.html$/, '');
        window.history.replaceState(null, '', newUrl);
    }
}