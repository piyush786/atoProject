var serviceURL1 = '/svc/CEDService.svc/';

/// this is the standard ajax call this will be used for most methods
//function ServiceMethodName(msg) {
//   getAjaxJSON('ServiceMethodName', 
//                 onSuccess <== callback function to execute when requests completes.
//                 onError <== optional callback function to execute if requests fails. If not specified, default error function will be used.
//                 msg <== optional valid json object to pass to service method
//  return;};

//example: 
//function GetEmployeeInformation(data) {getAjaxJSON('GetEmployeeInformation', GetEmployeeInformationSuccess, null, data); return;};

function Hrp_getAjaxJSON_WithOutValidation(method, onSuccess, onError, data, isAsynch) {    
    if (isAsynch == undefined || isAsynch == null) { isAsynch = true };
    if (!onError) { onError = StandardDevError };
     jQuery.ajax({
        cache: false,
        asynch: isAsynch,
        contentType: "application/json; charset=utf-8",
        type: "POST",
        dataType: "json",
        data: jQuery.toJSON(data),
        url: serviceURL1 + method,
        success: onSuccess,
        error: onError
    }); return;
};
function Hrp_getAjaxJSON(method, onSuccess, onError, data, isAsynch) {
 
    if (isAsynch == undefined || isAsynch == null) { isAsynch = true };
    if (!onError) { onError = StandardDevError };
    jQuery.ajax({
        cache: false,
        asynch: isAsynch,
        contentType: "application/json; charset=utf-8",
        type: "POST",
        dataType: "json",
        data: jQuery.toJSON(data),
        url: serviceURL1 + "GetSessionActiveOrNot",
        success:
        function (msgz) {

            if (msgz) {
                jQuery.ajax({
                    cache: false,
                    asynch: isAsynch,
                    contentType: "application/json; charset=utf-8",
                    type: "POST",
                    dataType: "json",
                    data: jQuery.toJSON(data),
                    url: serviceURL1 + method,
                    success: onSuccess,
                    error: onError
                });
            }
            else {
                HRP_GetSessionActiveOrNotError(msgz);
            }
        },
        error: HRP_GetSessionActiveOrNotError
    }); return;
};


function getAjax(_url) {
   console.log("URL"+_url)
           $.ajax({
               cache: false,
               asynch: true,
               crossDomain: true,
               contentType: "application/json; charset=utf-8",
               type: "GET",
               dataType: "jsonp",
               jsonp: 'jsonp_callback',
               url: _url,
               success: function (data) {
                   alert("Success");
                   console.log(data);
               },
               error: function (msg, status) {
                   alert("Fail");

               }
           });
       }


//function HRP_GetSessionActiveOrNotError(msg) {
//if(IsLiveSite=='true'){
//    // window.location = '/svc/Sessionkill.ashx';
//    window.location.href = "/svc/HRPSessionKill.ashx";
//    }
//}



//for HRP by sneha

function LoginHRP(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('LoginHRP', onSuccess, onError, msg); return;
};

//Save Survey Response
function SaveSurveyAnswerModel(data) {
    Hrp_getAjaxJSON_WithOutValidation('SaveEmployeeSurveyResponse', onSuccess, onError, data, null); return;
};

function HRP_SaveUpdateSaveScenarios(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SaveUpdateSaveScenarios', onSuccess, onError, msg); return;
};

function HRP_SaveUpdateTrsData(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SaveUpdateTrsData', onSuccess, onError, msg); return;
};

function HRP_SendUserTempPassword(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SendUserTempPassword', onSuccess, onError, msg); return;
};

function CUserselectedUICulture(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('CUserselectedUICulture', onSuccess, onError, msg); return;
};

function HRP_ValidateThreeStepLogin(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateThreeStepLogin', onSuccess, onError, msg); return;
};


function Hrp_CheckAttempts(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_CheckAttempts', onSuccess, onError, msg); return;
};

function HRP_ValidateUserSelfReg_Bayer(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateUserSelfReg_Bayer', onSuccess, onError, msg); return;
}; 
 
function Hrp_GetSecurityModel(OnSuccessLoad, OnErrorLoad) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_GetSecurityChoicesModel', OnSuccessLoad, OnErrorLoad, null, null); return;
};

function GetClientPasswordStrength(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('GetClientPasswordStrength', onSuccess, onError, msg); return;
};

function Hrp_SetSecurityChoicesAndPassword(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_SetSecurityChoicesAndPassword', Hrp_SaveSecurityChoicesModelSuccess, Hrp_SaveSecurityChoicesModelError, msg); return;
};

function Hrp_SetPassword_Mepp(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_SetPassword_Mepp', Hrp_SaveSecurityChoicesModelSuccess, Hrp_SaveSecurityChoicesModelError, msg); return;
};

function Hrp_SetPassword_Bayer(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_SetPassword_Bayer', Hrp_SaveSecurityChoicesModelSuccess, Hrp_SaveSecurityChoicesModelError, msg); return;
};

function Hrp_SetPassword_Michelin(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_SetPassword_Michelin', Hrp_SaveSecurityChoicesModelSuccess, Hrp_SaveSecurityChoicesModelError, msg); return;
};
function HRP_SaveUpdateSaveScenariosCMHC(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SaveUpdateSaveScenariosCMHC', onSuccess, onError, msg); return;
};


function Hrp_GetClientPasswordStrength(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('GetClientPasswordStrength', onSuccess, onError, msg); return;
};


function HRP_GetPasswordResetInformation(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_GetPasswordResetInformation', onSuccess, onError, msg); return;
};

function Hrp_ForgotAttempts(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_ForgotAttempts', onSuccess, onError, msg); return;
};

function HRP_ValidateSecurityAnswers(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateSecurityAnswers', onSuccess, onError, msg); return;
};

function HRP_ResetSendUserPassword(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ResetSendUserPassword', onSuccess, onError, msg); return;
};


function GetUserEnabledStatus(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('GetUserEnabledStatus', onSuccess, onError, msg); return;
};
function GetUserEnabledStatusMepp(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('GetUserEnabledStatusMepp', onSuccess, onError, msg); return;
};

function HRP_SelfResetPasswordWithTempPass(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SelfResetPasswordWithTempPass', onSuccess, onError, msg); return;
};

function HRP_SelfResetPasswordWithOutTempPass(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SelfResetPasswordWithOutTempPass', onSuccess, onError, msg); return;
};

function LoginHRP_Counter(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('LoginHRP_Counter', onSuccess, onError, msg); return;
};

// for validating from db password 

function VerifyPasswordStrength(mssg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('VerifyPasswordStrength', onSuccess, onError, mssg); return;
};

function ResetUserPassword(data, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('ResetUserPassword', onSuccess, onError, data); return;
};

function HRP_ValidateUserSelfReg_Dropdown(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateUserSelfReg_Dropdown', onSuccess, onError, msg); return;
};

function Hrp_isValidUsername(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_isValidUsername', onSuccess, onError, msg); return;
};

function ToggleTempPassword(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('ToggleTempPassword', onSuccess, onError, msg); return;
};

function HRP_PageTypeSelfResetPassword(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_PageTypeSelfResetPassword', onSuccess, onError, msg); return;
};

function Hrp_isValidNewHire(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_isValidNewHire', onSuccess, onError, msg); return;
};

function Hrp_isDisableUsername(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_isDisableUsername', onSuccess, onError, msg); return;
};

function Hrp_UserLocked(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_UserLocked', onSuccess, onError, msg); return;
};

function HRP_ValidateThreeStepLoginCustomLanguage(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateThreeStepLoginCustomLanguage', onSuccess, onError, msg); return;
};

function HRP_ValidateUserSelfReg_HSBC(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateUserSelfReg_HSBC', onSuccess, onError, msg); return;
};


function Hrp_GetSecurityModel(OnSuccessLoad, OnErrorLoad) {
    Hrp_getAjaxJSON_WithOutValidation('Hrp_GetSecurityChoicesModel', OnSuccessLoad, OnErrorLoad, null, null); return;
};

function HRP_SelfResetPasswordWithTempPass_HSBC(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SelfResetPasswordWithTempPass_HSBC', onSuccess, onError, msg); return;
};

function HRP_SendUserTempPassword_hsbc(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SendUserTempPassword_hsbc', onSuccess, onError, msg); return;
};

function HRP_ValidateUserSelfReg_Mepp(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateUserSelfReg_Mepp', onSuccess, onError, msg); return;
};

function HRP_ValidateUserSelfReg_Edmonton(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateUserSelfReg_Edmonton', onSuccess, onError, msg); return;
};

function HRP_ValidateUserSelfReg_Law(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_ValidateUserSelfReg_Law', onSuccess, onError, msg); return;
};

function HRP_SelfResetPasswordAonCanada(msg, onSuccess, onError){

Hrp_getAjaxJSON_WithOutValidation('HRP_SelfResetPasswordAonCanada', onSuccess, onError, msg); return;

};

function ResetTempPassword_Aon(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('ResetTempPassword_Aon', onSuccess, onError, msg); return;
};

function ResetCustomTempPassword_Aon(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('ResetCustomTempPassword_Aon', onSuccess, onError, msg); return;
};


function FirstTimeUserVFPA(msg, onSuccess, onError) {
    
Hrp_getAjaxJSON_WithOutValidation('FirstTimeUserVFPA', onSuccess, onError, msg); return;
//console.log(msg);
//getAjax("https://vfpa.ce.qc.alight.com/HRP/VfpaFTUHandler.ashx?request="+msg);
};

function HRP_SelfResetPasswordWithOutTempPass_MEPP(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SelfResetPasswordWithOutTempPass_MEPP', onSuccess, onError, msg); return;
};

function HRP_SelfResetPasswordHoag(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SelfResetPasswordHoag', onSuccess, onError, msg); return;
};

function HRP_SelfResetPasswordCMHCCandidate(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SelfResetPasswordCMHCCandidate', onSuccess, onError, msg); return;
};
function HRP_SelfResetPasswordParker(msg, onSuccess, onError) {
    Hrp_getAjaxJSON_WithOutValidation('HRP_SelfResetPasswordParker', onSuccess, onError, msg); return;
};