$(document).ready(function () {

    // 
    $("#dhsacontee").inputmask();

    //set input defaults
    var inputdata = JSON.parse(sessionStorage.getItem('SSOData')).input_data;

    //Medical dropdown

    var st = inputdata.input_STATE;

    if (st == "HI") {
        $("#dmedplan option:nth-child(5)").show();
        $("#dmedplan option:first-child,#dmedplan option:nth-child(2),#dmedplan option:nth-child(3),#dmedplan option:nth-child(4)").hide();
        $("#dmedplan").val("HMSA Hawaii PPO");
    } else {
        $("#dmedplan option:nth-child(5)").hide();
    }

    if (st == "CA") {
        $("#dmedplan option:nth-child(4)").show();
    } else {
        $("#dmedplan option:nth-child(4)").hide();
    }


    $("#main select").on("change", function () {
        excel2api(1); // 1 is a flag that says user did something; it's not page load anymore
    })
    $("#main input").on("change blur", function () {
        //  $(this).val(parseFloat($(this).val()))
        excel2api(1); // 1 is a flag that says user did something; it's not page load anymore
    });
    $("#main input").on("focus", function () {
        $(this).select();
    });

    excel2api();

});


function close_window() {
    top.window.opener = top;
    top.window.open('', '_parent', '');
    top.window.close();
}

function printPage() {
    print();
}

function cleanInput(theVal) {
    var cleaned = theVal.replace("$", "");
    cleaned = cleaned.replace(",", "");
    return cleaned;
}