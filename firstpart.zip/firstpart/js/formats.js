
//var DecimalPrecision = 0;
var selectedUICulture = "en";
function fmtCurrency(num, DecimalPrecision) {

    num = parseFloat(num);
    var decimalplaces = DecimalPrecision;
    var currencySymbol = '$';

    var thousandsSeparator = ',';
    if (selectedUICulture.toLowerCase() == "fr-ca")
        thousandsSeparator = ' ';
    else
        thousandsSeparator = ',';

    var number = num;
    number = isNaN(number) || number == '' || number == null ? 0.00 : number;
    decimalplaces = isNaN(decimalplaces) || decimalplaces == '' || decimalplaces == null ? 0 : decimalplaces;

    var numberStr = parseFloat(number).toFixed(decimalplaces).toString();
    var numberFormatted = new Array();
    if (decimalplaces > 0) {
        numberFormatted = new Array(numberStr.slice(-3));   // this returns the decimal and cents
        numberStr = numberStr.substring(0, numberStr.length - 3); // this removes the decimal and cents
    }

    while (numberStr.length > 3) {
        numberFormatted.unshift(numberStr.slice(-3)); // this prepends the last three digits to `numberFormatted`
        numberFormatted.unshift(thousandsSeparator); // this prepends the thousandsSeparator to `numberFormatted`
        numberStr = numberStr.substring(0, numberStr.length - 3);  // this removes the last three digits
    }
    numberFormatted.unshift(numberStr); // there are less than three digits in numberStr, so prepend them
    numberFormatted = numberFormatted.join(''); // put it all together

    if (selectedUICulture.toLowerCase() == "fr-ca") {
        numberFormatted = numberFormatted + ' ' + currencySymbol;
        numberFormatted = numberFormatted.replace('.', ',');
    }
    else
        numberFormatted = currencySymbol + numberFormatted;
    //    numberFormatted.unshift(currencySymbol);  // prepend the currencySymbol

    return numberFormatted;
}
/* ends here */




function format(theVal, numDec) {
    var NumCommas; var str = "" + Math.round(theVal * Math.pow(10, numDec))
    while (str.length <= numDec) { str = "0" + str }
    var decPoint = str.length - numDec; var tmp1 = str.substring(0, decPoint); var sLen = parseInt(tmp1.length); var tmp2 = str.substring(decPoint, str.length)
    NumCommas = (sLen > 3 && sLen < 7) ? 1 : 2; if (sLen < 4) { NumCommas = 0 }
    if (sLen > 3 && sLen < 10) { str = (sLen > 3 && sLen < 7) ? str = str.substring(0, sLen - 3) + "," + str.substring(sLen - 3, decPoint) : str = str.substring(0, sLen - 6) + "," + str.substring(sLen - 6, sLen - 3) + "," + str.substring(sLen - 3, decPoint) }
    //	str=(numDec != 0)?str.substring(0, (decPoint+NumCommas))+"."+str.substring((decPoint+NumCommas), str.length):str.substring(0,(decPoint+NumCommas))
    str = (numDec != 0) ? str.substring(0, (decPoint + NumCommas)) + "." + tmp2 : str.substring(0, (decPoint + NumCommas))
    if (str.charAt(str.length - 1) == ".") { str += "00" }
    return str
}

//function fmtCurrency(theVal, numDec){
//return "$" + format(theVal,numDec)}

function fmtPercent(theVal, numDec) {
    return format(theVal, numDec) + "%"
}

function fmtDate(theVal) {
    var monthArr = new Array(12)
    monthArr[0] = "January"; monthArr[1] = "February"; monthArr[2] = "March"; monthArr[3] = "April"; monthArr[4] = "May"; monthArr[5] = "June"
    monthArr[6] = "July"; monthArr[7] = "August"; monthArr[8] = "September"; monthArr[9] = "October"; monthArr[10] = "November"; monthArr[11] = "December"

    var str1 = theVal
    var yr = ""
    var test1 = str1.indexOf("/")
    if (test1 > 0) {
        var p1 = str1.substring(0, test1)
        //	if(parseInt(p1)<10){p1="0"+p1}
        str1 = theVal.substring(test1 + 1, theVal.length)
        test1 = str1.indexOf("/")
        var p2 = str1.substring(0, test1)
        str1 = str1.substring(test1 + 1, theVal.length)
        var p3 = str1
        var d = new Date(parseInt(p3), parseInt(p1) - 1, parseInt(p2))
        yr = d.getFullYear()
        if (p3 < 33) { yr += 100 }
        return monthArr[parseInt(p1) - 1] + " " + p2 + ", " + yr
    }
}
