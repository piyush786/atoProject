
//var DecimalPrecision = 0;

function fmtCurrency(num, DecimalPrecision) {
    num = parseFloat(num);
    var decimalplaces = DecimalPrecision;
    var currencySymbol = '$';

    var thousandsSeparator = ',';
    if (CMS.Application.language == "fr")
        thousandsSeparator = ' ';
    else
        thousandsSeparator = ',';

    var number = num;
    number = isNaN(number) || number == '' || number == null ? 0.00 : number;
    decimalplaces = isNaN(decimalplaces) || decimalplaces == '' || decimalplaces == null ? 0 : decimalplaces;

    var numberStr = parseFloat(number).toFixed(decimalplaces).toString();
    var numberFormatted = new Array();
    if (decimalplaces > 0) {
        numberFormatted = new Array(numberStr.slice(-3));   // this returns the decimal and cents
        numberStr = numberStr.substring(0, numberStr.length - 3); // this removes the decimal and cents
    }

    while (numberStr.length > 3) {
        numberFormatted.unshift(numberStr.slice(-3)); // this prepends the last three digits to `numberFormatted`
        numberFormatted.unshift(thousandsSeparator); // this prepends the thousandsSeparator to `numberFormatted`
        numberStr = numberStr.substring(0, numberStr.length - 3);  // this removes the last three digits
    }
    numberFormatted.unshift(numberStr); // there are less than three digits in numberStr, so prepend them
    numberFormatted = numberFormatted.join(''); // put it all together

    if (CMS.Application.language == "fr") {

        numberFormatted = numberFormatted + ' ' + currencySymbol;
        numberFormatted = numberFormatted.replace('.', ',');
    }
    else
        numberFormatted = currencySymbol + numberFormatted;
    //    numberFormatted.unshift(currencySymbol);  // prepend the currencySymbol

    return numberFormatted;
}
/* ends here */








function format(theVal, numDec){
	var NumCommas;var str=""+Math.round(theVal*Math.pow(10, numDec))
	while(str.length<=numDec){str="0"+str}
	var decPoint=str.length-numDec;var tmp1=str.substring(0, decPoint);var sLen=parseInt(tmp1.length);var tmp2=str.substring(decPoint, str.length)
	NumCommas=(sLen>3&&sLen<7)?1:2;if(sLen<4){NumCommas=0}
	if(sLen>3&&sLen<10){str=(sLen>3&&sLen<7)?str=str.substring(0, sLen-3)+" "+str.substring(sLen-3, decPoint):str=str.substring(0, sLen-6)+" "+str.substring(sLen-6, sLen-3)+" "+str.substring(sLen-3, decPoint)}
//	str=(numDec != 0)?str.substring(0, (decPoint+NumCommas))+","+str.substring((decPoint+NumCommas), str.length):str.substring(0,(decPoint+NumCommas))
	str=(numDec != 0)?str.substring(0, (decPoint+NumCommas))+","+tmp2:str.substring(0,(decPoint+NumCommas))
	if(str.charAt(str.length-1)==","){str+="00"}
	return str
}

//function fmtCurrency(theVal, numDec){
//return format(theVal,numDec)+"�$"}

function fmtPercent(theVal, numDec){
return format(theVal,numDec)+"%"}

function fmtDate(theVal,enDate){
var monthArr=new Array(12)
monthArr[0]="janvier";monthArr[1]="février";monthArr[2]="mars";monthArr[3]="avril";monthArr[4]="mai";monthArr[5]="juin"
monthArr[6]="juillet";monthArr[7]="aout";monthArr[8]="septembre";monthArr[9]="octobre";monthArr[10]="novembre";monthArr[11]="décembre"
var monthArrEN=new Array(12)
monthArrEN[0]="January";monthArrEN[1]="February";monthArrEN[2]="March";monthArrEN[3]="April";monthArrEN[4]="May";monthArrEN[5]="June"
monthArrEN[6]="July";monthArrEN[7]="August";monthArrEN[8]="September";monthArrEN[9]="October";monthArrEN[10]="November";monthArrEN[11]="December"

var str1=theVal
var yr=""
var test1=str1.indexOf("/")
var test2=str1.indexOf(",")
if(test1>0){
  var p1=str1.substring(0,test1)
//	if(parseInt(p1)<10){p1="0"+p1}
  str1=theVal.substring(test1+1,theVal.length)
	test1=str1.indexOf("/")
  var p2=str1.substring(0,test1)
  str1=str1.substring(test1+1,theVal.length)
  var p3=str1
	var d= new Date(parseInt(p3),parseInt(p1)-1,parseInt(p2))
	yr=d.getFullYear()
	if(p3<33){yr+=100}
	var dayStr=(p2==1)?"1er ":p2+" "
  if(enDate==1){return monthArrEN[parseInt(p1)-1] + " " + p2 + ", " + yr}else{
	return dayStr + monthArr[parseInt(p1)-1] + " " + yr}
}else if(test2>0){
  var d=new Date(theVal)
//	if(parseInt(p1)<10){p1="0"+p1}
	return d.getDate() + "&nbsp;" + monthArr[d.getMonth()] + "&nbsp;" + d.getFullYear();
}
}
